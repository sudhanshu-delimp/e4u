@extends('layouts.web')
@section('style')
        
<style>
    .loader {
    border: 16px solid #f3f3f3;
    border-radius: 50%;
    border-top: 16px solid #3498db;
    width: 120px;
    height: 120px;
    -webkit-animation: spin 2s linear infinite; /* Safari */
    animation: spin 2s linear infinite;
    }
    /* Safari */
    @-webkit-keyframes spin {
    0% { -webkit-transform: rotate(0deg); }
    100% { -webkit-transform: rotate(360deg); }
    }
    @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
    }
</style>
@endsection
@section('content')
<section class="padding_top_eight_px padding_bottom_eight_px">
    <div class="container">
        <h1 class="home_heading_first margin_btm_twenty_px">Abbreviations, Icons & Lingo</h1>
        <div class="accordion-container">
            <div class="set">
                <a>
                Introduction
                <i class="fa fa-angle-down"></i>
                </a>
                <div class="content">
                    <div class="accodien_manage_padding_content">
                        <p><b>An overview</b>
                        <p>There are many abbreviations used by us and Advertisers throughout this Website. The
                            escort industry in particular is renowned for having its own language as well as for
                            describing certain activities on certain occasions. Much of the language, or lingo as it is
                            often referred to as, is understood only by experienced clients of and the escorts
                            themselves. 
                        </p>
                        <p>Many newcomers to the escort industry often find the use of the lingo daunting, and
                            become frustrated trying to get their head around it. This can often lead to a
                            misunderstanding between the client and the escort which is not a preferred outcome for
                            either party.
                        </p>
                        <p>Similarly, it is important to understand what a Massage Centre’s service offering is so that
                            there are no misunderstandings between the client and the Masseur.
                        </p>
                        <p>It is important for clients of escort and massage services to have a full understanding of
                            what is being offered. A prospective client needs to know in advance:
                        </p>
                        <ul>
                            <li>What the boundaries for an Escort and Massage Centre are</li>
                            <li>If the Escort or Masseur they are looking at in the Profile can fulfill the fantasies or
                                services they are looking for; and
                            </li>
                            <li>The Escort can provide the services that they are seeking</li>
                        </ul>
                        <p>So communication of the services on offer and the understanding of them are important to
                            having a memorable and pleasant experience. To help you come to an informed decision,
                            along with these abbreviations, Profiles are designed so as to ensure as much of the
                            information an Escort or Massage Centre is advertising, is accurate. In addition to the
                            industry lingo so widely used, which we have incorporated into the Profiles, we have also
                            set out abbreviations and icons used by us in this Website to also assist you.
                        </p>
                        <p><b>Capitalisation, Nouns and Dates</b></p>
                        <p>Wherever you see a word that has a capital, like for example "Escort" or "Viewer", it
                            means the word has a specific meaning and is defined in the section below - Website
                            Abbreviations.
                        </p>
                        <p>Dates are expressed as dd-mm-20yy</p>
                    </div>
                </div>
            </div>
            <div class="set">
               <a>
                  Industry lingo
               <i class="fa fa-angle-down"></i>
               </a>
               <div class="content">
                   <div class="accodien_manage_padding_content">
                       <p></p>
                       <div class="row">
                           <div class="col-lg-4">
                              <h2>A</h2>
                              <p><strong>Anal play:</strong> refers to any kind of external play or penetration of the anus, either by the use of a finger, tongue, sex toys, or penis<br>
                              <strong>Anal sex:</strong> penetration of the penis inside the anus, also referred to as greek<br>
                              <strong>ATM:</strong> ass to mouth. Involves acts such as giving oral sex immediately after receiving anal sex, or putting a finger or a vibrator in one's mouth immediately after anal penetration</p>
                              </ul>
                              <ul style="padding: 0;">
                              <h2>B</h2>
                              <p><strong>Bi twin:</strong> a double booking with two bisexual escorts<br>
                              <strong>BJ:</strong> blow job, oral sex<br>
                              <strong>BBBJ:</strong> bare back blow job. Giving unprotected oral sex to a man.<br>
                              <strong>BBBJTC:</strong> bare back blow job to completion<br>
                              <strong>BBW:</strong> big beautiful woman. A woman who is Rubenesque, voluptuous, curvy.<br>
                              <strong>BLS:</strong> balls licking and sucking<br>
                              <strong>B&amp;D:</strong> bondage &amp; discipline<br>
                              <strong>BDSM:</strong> bondage domination sadomasochism<br>
                              <strong>B&amp;G:</strong> blow &amp; go<br>
                              <strong>Bondage:</strong> sexual act that involves the tying up or restraining of one partner<br>
                              <strong>Brazilian:</strong> a form of bikini wax that removes the hair from the front, middle and rear of a woman's pubic area. A "landing strip" is sometimes left at the front, others opt to have the hair completely removed<br>
                              <strong>BS:</strong> body slide. An escort seductively slides their naked body over yours</p>
                              </ul>
                              <ul style="padding: 0;">
                              <h2>C</h2>
                              <p><strong>CBT:</strong> cock and ball torture. A BDSM sexual activity involving torture or pain affliction of the male genitals<br>
                              <strong>CD:</strong> cross dressing. A man who derives pleasure from dressing in clothes appropriate to the opposite sex<br>
                              <strong>CIM:</strong> cum in mouth. To ejaculate in the mouth<br>
                              <strong>CIMWS:</strong> cum in mouth with swallow. To ejaculate in the mouth and swallow the fluid<br>
                              <strong>CBJ:</strong> covered blow job. Protected oral sex with a condom<br>
                              <strong>COB:</strong> cum on body. To ejaculate on a person's body<br>
                              <strong>COF:</strong> cum on face. To ejaculate on a person's face<br>
                              <strong>Cougar:</strong> a more mature woman seeking a sexual relationship with a younger man<br>
                              <strong>Costumes and role play:</strong> the wearing of fantasy outfits and assuming the roles of characters, to heighten sexual excitement. Such examples of fantasy costumes can be nurse, school girl, maid, secretary and mistress<br>
                              <strong>Couples:</strong> a couple in a relationship. An escort that includes "couples" in her services list means she provides a bisexual service to a couple</p>
                              </ul>
                              <ul style="padding: 0;">
                              <h2>D</h2>
                              <p><strong>DATY:</strong> stands for Dining At The Y. Performing oral sex on a woman<br>
                              <strong>DATO:</strong> see rimming<br>
                              <strong>DFK:</strong> deep French kissing. Tongue kissing<br>
                              <strong>Dinner companion:</strong> a social escort who accompanies you to dinner. May or may not provide sexual services<br>
                              <strong>Dirty talk:</strong> the practice of using graphic words to heighten sexual pleasure during intimacy<br>
                              <strong>DP:</strong> double penetration. Two men penetrate one woman with vaginal and anal sex<br>
                              <strong>DDP:</strong> double digit penetration. One finger in the vagina, and the other in the anus<br>
                              <strong>DT:</strong> deep throat. The technique of taking the entire length of a man's penis in one's mouth and giving oral sex<br>
                              <strong>Doggy style:</strong> a sexual position, where the man penetrates a woman from behind</p>
                              </ul>
                           </div>
                           <div class="col-lg-4">
                               <!-- <p></p> -->
                              <h2>E</h2>
                              <p><strong>Erotic sensual massage:</strong> a body rub that is intended to sexually stimulate the receiver</p>
                              </ul>
                              <ul style="padding: 0;">
                              <h2>F</h2>
                              <p><strong>Facial:</strong> ejaculating on a woman's face<br>
                              <strong>FE:</strong> female ejaculation during orgasm. Also referred to as squirting<br>
                              <strong>Fetish:</strong> a need or desire for an object, body part, or activity for sexual excitement<br>
                              <strong>Filming:</strong> the film or digital recording of a sexual act<br>
                              <strong>Fire and ice:</strong> giving oral sex and switching between hot tea and cold ice cube<br>
                              <strong>Fisting:</strong> the penetration of the whole hand inside the vagina or anus<br>
                              <strong>FK:</strong> French kissing. Tongue kissing<br>
                              <strong>Foot fetish:</strong> a pronounced sexual interest and gratification in feet or shoes<br>
                              <strong>French:</strong> oral sex, fellation<br>
                              <strong>FS:</strong> full service. Refers to an escort providing a full sex service<br>
                              </p></ul>
                              <ul style="padding: 0;">
                              <h2>G</h2>
                              <p><strong>Gagging:</strong> a sexual act of gratification where the female gags or chokes on a man's erect penis<br>
                              <strong>GFE:</strong> girlfriend experience. A very intimate service, where the escort is more like a girlfriend. May include such services as sex, french kissing and mutual oral sex. The details of each escort's girlfriend experience can vary, and confirmation about her services is recommended.<br>
                              <strong>Greek:</strong> anal sex<br>
                              <strong>GS:</strong> golden shower. Involves watching an escort urinate, or one person passing water on another</p>
                              </ul>
                              <ul style="padding: 0;">
                              <h2>H</h2>
                              <p><strong>Happy ending:</strong> hand job after massage<br>
                              <strong>HJ:</strong> hand job. Sexually stimulating the penis by hand</p>
                              </ul>
                              <ul style="padding: 0;">
                              <h2>I</h2>
                              <p><strong>Italian:</strong> rubbing penis between the buttocks</p>
                              </ul>
                              <ul style="padding: 0;">
                              <h2>L</h2>
                              <p><strong>LK:</strong> light kissing. Usually with a closed mouth</p>
                              </ul>
                              <ul style="padding: 0;">
                              <h2>M</h2>
                              <p><strong>MILF:</strong> mother I'd like to fuck. Describes a sexually attractive female, usually several years older than the person using the term<br>
                              <strong>MFF:</strong> male female female. A threesome with one man and two women<br>
                              <strong>MMF:</strong> male male female. A threesome with two men and one woman<br>
                              <strong>Multiple positions:</strong> an escort who allows you to have sex in many different styles and positions<br>
                              <strong>Masturbation:</strong> sexually arousing one's self, usually to the point of orgasm. Can be performed by use of fingers, hands, an object, or a sex toy<br>
                              <strong>Mutual masturbation:</strong> escort and client sexually arousing themselves, while they voyeuristically watch each other<br>
                              <strong>Mutual French:</strong> Both parties will give and reciprocate oral sex. If done at the same time, is referred to as a 69<br>
                              <strong>Mutual natural French:</strong> both parties give and receive unprotected oral sex<br>
                              <strong>MSOG:</strong> multiple shots on goal. An escort providing MSOG service will allow a client to orgasm multiple times</p>
                              </ul>
                           </div>
                           <div class="col-lg-4">
                              <h2>N</h2>
                              <p><strong>Natural bush:</strong> unshaven or unwaxed pubic hair</p>
                              </ul>
                              <ul style="padding: 0;">
                              <h2>O</h2>
                              <p><strong>OWO:</strong> oral without a condom<br>
                              <strong>Overnight stays:</strong> an escort who stays overnight at a client's hotel or residence</p>
                              </ul>
                              <ul style="padding: 0;">
                              <h2>P</h2>
                              <p><strong>Photography:</strong> the photographing of a sexual act<br>
                              <strong>PNDP:</strong> please, no dick pics<br>
                              <strong>Prostate massage:</strong> the massage or stimulation of the male prostate gland by anal penetration, for sexual stimulation. Sometimes referred to as the male G-spot<br>
                              <strong>PSE:</strong> porn star experience. A sexual encounter that is very similar to what you would see in a pornographic film. Involves a wide range of sexual positions and tends to be very hardcore. The details of each escort's porn star experience can vary, and confirmation about her services is recommended.<br>
                              <strong>Punter:</strong> the client or customer of an escort</p>
                              </ul>
                              <ul style="padding: 0;">
                              <h2>R</h2>
                              <p><strong>Role play:</strong> assuming the roles of characters, to heighten sexual excitement<br>
                              <strong>Rimming:</strong> licking the anus</p>
                              </ul>
                              <ul style="padding: 0;">
                              <h2>S</h2>
                              <p><strong>Sex toy:</strong> an object or device that is primarily used to facilitate human sexual pleasure. Includes such instruments as dildos, vibrators and strap ons.<br>
                              <strong>Snowballing:</strong> the act of transferring semen or cum from one person's mouth to another<br>
                              <strong>Spanish:</strong> rubbing the penis between an escorts breasts, sometimes until climax<br>
                              <strong>Spanking:</strong> the act of slapping another person's buttocks for the sexual arousal or gratification of either or both parties<br>
                              <strong>Spit roasting:</strong> A woman giving oral sex to one male whilst being penetrated from behind.<br>
                              <strong>Squirting:</strong> a female ejaculating fluid from her vagina during orgasm<br>
                              <strong>Strap on:</strong> A dildo designed to be worn, usually with a harness, to penetrate a sexual partner<br>
                              <strong>Strip tease:</strong> an erotic dance, where the escort slowly undressed for her client in a teasing fashion</p><p>
                              </p></ul>
                              <ul style="padding: 0;">
                              <h2>T</h2>
                              <p><strong>Tea bagging:</strong> placing a man's balls in the mouth of a partner<br>
                              <strong>Toy show:</strong> a masturbation show, by use of sex toys including vibrators<br>
                              <strong>Tromboning:</strong> an act where a female kneels behind her male partner and licks his anus while masturbating his erect penis<br>
                              <strong>TTM:</strong> testicular tongue massage</p>
                              </ul>
                              <ul style="padding: 0;">
                              <h2>U</h2>
                              <p><strong>Ugly Mug:</strong> a person who has in some way offended or victimised an Escort</p>
                              </ul>
                              <ul style="padding: 0;">
                              <h2>W</h2>
                              <p><strong>Water sports:</strong> see golden shower<br>
                              <strong>WL:</strong> working lady, escort</p><br><br><br><br><br><br><br><br><br>
                              </ul>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
            <div class="set">
                <a> Website abbrieviations
                  
                <i class="fa fa-angle-down"></i>
                </a>
                <div class="content">
                    <div class="accodien_manage_padding_content">
                        <p><b>An overview</b></p>
                        <p>These Website Abbreviations (<b>Abbreviations</b>) are to be read in conjunction with the
Terms and Conditions. To the extent of any inconsistency between these Abbreviations
and the Terms and Conditions, the <a href="{{ url('terms-conditions')}}" class="termsandconditions_text_color text-decoration-none">Terms and Conditions</a> prevail.</p>
                        <div class="row">
                            <div class="col-lg-4">
                                <h2>A</h2>
                                <p style="border-top: 0px;"><b>A-Alert:</b> means an email or text message (notification)
                                    being forwarded to a Viewer by an Advertiser
                                    alerting the Viewer to an information update.
                                </p>
                                <p><b>Account or My Account: </b>has the same meaning as “<a href="#" class="termsandconditions_text_color text-decoration-none">Account</a>” described in
                                    the Terms.
                                </p>
                                <p><b>Advertiser: </b>has the same meaning as “<a href="#" class="termsandconditions_text_color text-decoration-none">Advertiser</a>” described
                                    in the Terms.
                                </p>
                                <p><b>Advertiser Home Page: </b>means either of or collectively the Escort Home
                                    Page or Massage Centre Home Page.
                                </p>
                                <p><b>Agent</b> or <b>Agency: </b>means a registered business or incorporated body
                                    pursuant to the Corporations Act and which has
                                    been appointed by Escorts4U as an Agent to
                                    undertake and to provide certain services to
                                    Advertisers.
                                </p>
                                <p><b>Agent Agreement: </b>means the written agreement entered into
                                    between the Agent and Escorts4U together with
                                    any schedules or documents incorporated by
                                    reference, and any variations thereof.
                                </p>
                                <p><b>Agent ID: </b>means the reference number allocated to the
                                    Agent by Escorts4U and which identifies the said
                                    Agent.
                                </p>
                                <p><b>Agent Log: </b>means the log and data files that are recorded for
                                    collecting and correlating Agent information within
                                    User interactions and sessions.
                                </p>
                                <p><b>Agent Services: </b>means either of or all of the services provided to
                                    an Advertiser by the Agent whereby the Agent, as
                                    proxy, manages the Advertiser’s Profiles, Tours,
                                    Media, Concierge Services, Account information
                                    and all matters associated with the said services.
                                </p>
                                <p><b>Alert/s: </b>means either of, or collectively, an A-Alert or
                                    V-Alert or W-Alert.
                                </p>
                                <p><b>Archive Folder: </b>means the location within your Dashboard where
                                    you store Profiles and Media.
                                </p>
                                <h2>B</h2>
                                <p><b>Bank: </b>means any bank domiciled in Australia.</p>
                                <p><b>Banner Image:</b> means the landscape photo image contained in
                                    your Archive Folder and which you have
                                    designated as the default display photo image
                                    displayed across the top of a Profile (in
                                    landscape).
                                </p>
                                <h2>C</h2>
                                <p><b>Card: </b>means either of the Advertiser’s credit or debit
                                    cards, details of which the Advertiser will provide
                                    Escorts4U when paying any Fees.
                                </p>
                                <p><b>Carousel: </b>means</p>
                                <p><b>Classification Laws:</b> means the respective State and Commonwealth
                                    laws which govern the publication of restrictive
                                    material.
                                </p>
                                <p><b>Cookie/s: </b>means a small piece of data transmitted by
                                    Escorts4U from our web server that is stored on
                                    the User's hard drive or other storage device.
                                    Disabling or deleting cookies may result in the
                                    unavailability of some functions and features of
                                    the Website.
                                </p>
                                <p><b>Concierge Services: </b>means any of or all of the concierge services
                                    provided by Escorts4U to an Advertiser on the
                                    Website and which are accessed through the
                                    Dashboard.
                                </p>
                                <p><b>Corporations Act: </b>has the same meaning as “<a href="#" class="termsandconditions_text_color text-decoration-none">Corporations Act</a>”
                                    described in the Terms.
                                </p>
                                <p><b>Credit/s: </b>means any amount of money you have paid to
                                    Escorts4U in advance for payment of Services.
                                </p>
                                <h2>D</h2>
                                <p><b>Default Profile:</b> means the default Profile that the Website creates
                                    for you based on your Profile Information.
                                </p>
                                <p><b>Dashboard:</b> means your information management tool that
                                    visually displays your Account details, enables
                                    you to track, undertake tasks, analyse and display
                                    information.
                                </p>
                               <h2>E</h2>
                                <p><b>E4U: </b>has the same meaning as “<a href="#" class="termsandconditions_text_color text-decoration-none">E4U</a>” described in the
                                    Terms.
                                </p>
                                <p><b>E4U Verification Icon:</b>means the unique icon placed on a Verified Photo
                                    and which certifies the Media has been verified as
                                    authentic.
                                </p>
                                <p><b>Escort:</b>has the same meaning as “<a href="#" class="termsandconditions_text_color text-decoration-none">Escort</a>” described in
                                    the Terms.
                                </p>
                                <p><b>Escorts Home Page:</b> means the landing page that Profiles appear on,
                                    in a particular order according to the Membership
                                    type and which Viewers have a search facility.
                                </p>
                                <p><b>Escort Profile: </b>means the collective information posted by an
                                    Escort setting out information in relation to a
                                    Profile or Tour.
                                </p>
                                <p><b>Escorts4U </b>or <b>our</b> or <b>us</b> or <b>we</b> has the same meaning as E4U.</p>
                            </div>
                            <div class="col-lg-4">
                                <!-- <p></p> -->
                                <h2>F</h2>
                                <p><b>Favorite:</b> has the same meaning as Legbox.</p>
                                <p><b>Fee</b> or <b>Fees</b> has the same meaning as “<a href="#" class="termsandconditions_text_color text-decoration-none">Fees</a>
                                ” described in the
                                Terms.
                                </p>
                                <p><b>Footer:</b> means the block of text, links and icons located at
                                    the bottom of every page of this Website.
                                </p>
                                <p><b>Free: </b>means the lowest level of Membership an
                                    Advertiser can have on this Website. It is unpaid
                                    and has limitations placed on it.
                                </p>
                                <h2>G</h2>
                                <p><b>Geolocation: </b>has the same meaning as “<a href="#" class="termsandconditions_text_color text-decoration-none">Geolocation</a>”
                                described in the Terms.</p>
                                <p><b>Gold: </b>means the middle level of paid Membership an
                                    Advertiser has chosen to post a Profile or Tour.
                                </p>
                                <p><b>Grid View: </b>means a short version of a Profile displayed in a
                                    studio manner.
                                </p>
                                <h2>H</h2>
                                <p><b>Home Page:</b> means the default page a User lands on when
                                    entering the Website.
                                </p>
                                <p><b>Home State: </b>has the same meaning as “<a href="#" class="termsandconditions_text_color text-decoration-none">Home State</a>”
                                    described in the Terms.
                                </p>
                                <h2>I</h2>
                                <p><b>Incall: </b>means the Viewer is invited to the Advertiser's
                                    residence for companionship.
                                </p>
                                <h2>L</h2>
                                <p><b>Legbox: </b>means that group of Advertisers a Viewer has
                                    flagged in their favourites. A Viewer has to be a
                                    Member and logged on to access to the Legbox
                                    service.
                                </p>
                                <p><b>List View: </b>means a short version of a Profile displayed in a
                                    landscape/table manner.
                                </p>
                                <p><b>Local Laws: </b>means the respective State and Commonwealth
                                    laws which govern the provision of escort
                                    services, as defined in those laws, in your location
                                    (see also FAQs - <a href="#" class="termsandconditions_text_color text-decoration-none">Local Laws</a>).
                                </p>
                                <p><b>Location: </b>means the State, other than your Home State,
                                    that you are presently located in.
                                </p>
                                <h2>M</h2>
                                <p><b>Massage Centre:</b> has the same meaning as “<a href="#" class="termsandconditions_text_color text-decoration-none">Massage Centre</a>”
                                    described in the Terms.
                                </p>
                                <p><b>Massage Centre Home Page:</b> means the landing page that Massage Centre
                                    Profiles appear on and which Viewers have a
                                    search facility.
                                </p>
                                <p><b>Massage Centre Profile: </b> has the same meaning as “<a href="#" class="termsandconditions_text_color text-decoration-none">Massage Centre
                                    Profile</a>” described in the Terms.
                                </p>
                                <p><b>Masseur:</b> has the same meaning as “<a href="#" class="termsandconditions_text_color text-decoration-none">Masseur</a>” described in
                                    the Terms.
                                </p>
                                <p><b>Masseur Profile: </b> means the collective information of a Masseur
                                    posted within a Massage Centre Profile.
                                </p>
                                <p><b>Media:</b> means either of or collectively photo images or
                                    video files and includes your Thumbnail and
                                    Banner Image which is posted on a Profile.
                                </p>
                                <p><b>Member:</b>  or <b>Membership</b> has the same meaning as “<a href="#" class="termsandconditions_text_color text-decoration-none">Member</a> and
                                    Membership” described in the Terms.
                                </p>
                                <p><b>Membership Number:</b> means the unique number allocated to the
                                    Member by Escorts4U after having completed the
                                    online registration.
                                </p>
                                <p><b>Membership Type:</b> means either of or collectively the membership
                                    classes named Platinum, Gold, Sliver, Free or
                                    Massage Centre.
                                </p>
                                <h2>N</h2>
                                <p><b>Note:</b> means a record of Viewer points compiled in the
                                    Note creator regarding the Viewer’s experience
                                    with an Advertiser.
                                </p>
                                <p><b>Notifiable Data Breaches: </b> means the scheme administered under the
                                    Privacy Act.
                                </p>
                                <p><b>NUM:</b> means the National Ugly Mugs register,
                                    administered by Escorts4U.
                                </p>
                                <h2>O</h2>
                                <p><b>Outcall: </b> means the Advertiser agrees to attend at the
                                    Viewer's residence for companionship.
                                </p>
                            </div>
                            <div class="col-lg-4">
                                <h2>P</h2>
                                <p><b>Package/s:</b> means the benefits which are attached to a
                                    Membership Type.
                                </p>
                                <p><b>Payment Reference: </b>means the receipt number allocated to a payment
                                    of any Fees.
                                </p>
                                <p><b>Pin Up:</b> means the exclusive Profile of an Advertiser which
                                    appears on the Home Page.
                                </p>
                                <p><b>Platinum:</b> means the top level of paid Membership an
                                    Advertiser has chosen to post a Profile or Tour.
                                </p>
                                <p><b>POA</b>: Means, in relation to a Profile, price on
                                    application.
                                </p>
                                <p><b>Policy</b>: has the same meaning as “<a href="#" class="termsandconditions_text_color text-decoration-none">Policies</a>” described in
                                    the Terms.
                                </p>
                                <p><b>Privacy Act:</b> means the Privacy Act 1988 (Cth).</p>
                                <p><b>Profile</b> and <b> Profile Page</b>has the same meaning as “<a href="#" class="termsandconditions_text_color text-decoration-none">Profile</a>” described in
                                    the Terms.
                                </p>
                                <p><b>Profile ID Number:</b> means the unique number attached at a Profile.</p>
                                <p><b>Profile Information:</b> means any of, or the collective of, Account
                                    information and additional information not of a
                                    mandatary nature about themself and which is
                                    stored in your Dashboard and posted on the
                                    Profile Page.
                                </p>
                                <p><b>Profile Name:</b> means the stage name an Advertiser has
                                    allocated to a Profile.
                                </p>
                                <p><b>Profile Subscription:</b> means the amount of Fees paid to Escorts4U by
                                    an Advertiser for a Profile or Tour to be published
                                    on the Website for a set period of time.
                                </p>
                                <h2>S</h2>
                                <p><b>Search Page:</b> means the results page contained within the
                                    Website that lists the results (Profiles) of a search
                                    or query in response to either a specific link within
                                    the Website or a filter request contained within the
                                    search bar located on the Escorts Home Page.
                                </p>
                                <p><b>Service Tag: </b>means either of or collectively the itemised
                                    services which are performed on, or available to,
                                    a Viewer and the Advertiser and which are
                                    displayed on the Profile Page.
                                </p>
                                <p><b>Services: </b>has the same meaning as “<a href="#" class="termsandconditions_text_color text-decoration-none">Services</a>” described in
                                    the Terms.
                                </p>
                                <p><b>Silver:</b> means the bottom level of paid Membership an
                                    Advertiser has chosen to post a Profile or Tour.
                                </p>
                                <p><b>SMS 2FA:</b> means SMS based two-factor authentication and
                                    one-time password allowing Users to verify their
                                    identities with a code that is sent to the User via a
                                    text message to the nominated mobile number.
                                </p>
                                <p><b>Subscription</b> means the period of time a Viewer subscribes to
                                    the Website.
                                </p>
                                <p><b>Support Ticket:</b> means an online secure request from a User, via
                                    this Website, to Escorts4U raising an issue or
                                    requesting Escorts4U to look into and to resolve a
                                    request.
                                </p>
                                <p><b>SWA:</b> means the permit issued under the Safe Work Act
                                    in Victoria to operate without a licence as a small
                                    owner-operator, or to work as a sex worker,
                                    issued by the Business Licensing Authority.
                                </p>
                                <h2>T</h2>
                                <p><b>Terms:</b> has the same meaning as Terms and Conditions</p>
                                <p><b>Terms and Conditions:</b> means the terms and conditions, as amended
                                    from time to time, and as set out under the
                                    heading “Legal” in the Footer.
                                </p>
                                <p><b>Territory:</b> means the State or regions as specified in the
                                    Agent Agreement schedule.
                                </p>
                                <p><b>Thumbnail:</b> means the portrait photo image contained in your
                                    Archive Folder which you have designated as the
                                    default display photo image for all of your display
                                    photos that appear in a Profile (in portrait).
                                </p>
                                <p><b>Tour:</b> has the same meaning as “<a href="#" class="termsandconditions_text_color text-decoration-none">Tour</a>” described in the
                                    Terms.
                                </p>
                                <h2>U</h2>
                                <p><b>UMReport:</b> means the Ugly Mug Report, submitted by an
                                    Advertiser.
                                </p>
                                <p><b>User/s:</b> has the same meaning as “<a href="#" class="termsandconditions_text_color text-decoration-none">User</a>” described in the
                                    Terms.
                                </p>
                                <h2>V</h2>
                                <p><b>V-Alert:</b> means an email or text message being forwarded
                                    to a Viewer by either an Advertiser or Escorts4U
                                    alerting you to an update.
                                </p>
                                <p><b>Verified Photo:</b> means an Advertiser's photo submitted to
                                    Escorts4U together with a form of identity and
                                    which is matched by facial identity.
                                </p>
                                <p><b>Viewer:</b> has the same meaning as “<a href="#" class="termsandconditions_text_color text-decoration-none">Viewer</a>” described in
                                    the Terms.
                                </p>
                               <h2>W</h2>
                                <p><b>W-Alert:</b> means an email or text message being forwarded
                                    to a User by Escorts4U alerting the User of an
                                    update about the Website.
                                </p>
                                <p><b>Website:</b> has the same meaning as “<a href="#" class="termsandconditions_text_color text-decoration-none">Website</a>” described in
                                    the Terms
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="set">
               <a>
               Website icons
               <i class="fa fa-angle-down"></i>
               </a>
               <div class="content">
                   <div class="accodien_manage_padding_content">
                           <p><b>An overview</b></p>
                           <p class="mb-3">
                               These icons used in the Website <span class="bold-custon">(Icons)</span> are provided to assist Users navigate their way
                               through the Website and to provide clarity and certainty. The meaning ascribed to an Icon
                               should be read in conjunction with the <a href="{{ url('terms-conditions')}}" class="termsandconditions_text_color text-decoration-none">Terms and Conditions</a>. To the extent of any
                               inconsistency between the meaning ascribed to an Icon and the Terms and Conditions,
                               the <a href="{{ url('terms-conditions')}}" class="termsandconditions_text_color text-decoration-none">Terms and Conditions</a> prevail.
                           </p>

                           <p class="mb-3"><b>Icons</b></p>
                           <div class="row">
                           <div class="col-sm-12 col-lg-6 col-md-6">
                           
    
                                    <div class=" wi-icon-box">
                                        <div class="mr-3 wi-icon-icon">
                                         <img src="{{asset('assets/img/mobile-call.png')}}" alt="" class=" wi-icon">
                                        </div>
                                       <div class="wi-icon-content-box">
                                        <p class="wi-icon-content">means any User can call an Advertiser</p>
                                     </div>
                                    </div>
     
                                    <div class=" wi-icon-box">
                                     <div class="mr-3 wi-icon-icon">
                                      <img src="{{asset('assets/img/couple.png')}}" alt="" class=" wi-icon">
                                     </div>
                                    <div class="wi-icon-content-box">
                                     <p class="wi-icon-content">means an Advertiser will meet with a couple</p>
                                  </div>
                                 </div>
     
                                 <div class=" wi-icon-box">
                                     <div class="mr-3 wi-icon-icon">
                                      <img src="{{asset('assets/img/fb.png')}}" alt="" class=" wi-icon">
                                     </div>
                                    <div class="wi-icon-content-box">
                                     <p class="wi-icon-content">means the platform known as Facebook</p>
                                  </div>
                                 </div>
    
                                 <div class=" wi-icon-box">
                                    <div class="mr-3 wi-icon-icon">
                                     <img src="{{asset('assets/img/masseurs 2-plus.png')}}" alt="" class=" wi-icon">
                                    </div>
                                   <div class="wi-icon-content-box">
                                    <p class="wi-icon-content">means two Masseurs are available</p>
                                 </div>
                                </div>
    
                                <div class=" wi-icon-box">
                                    <div class="mr-3 wi-icon-icon">
                                     <img src="{{asset('assets/img/group.png')}}" alt="" class=" wi-icon">
                                    </div>
                                   <div class="wi-icon-content-box">
                                    <p class="wi-icon-content">means an Advertiser will meet with a group</p>
                                 </div>
                                </div>
     
                                <div class=" wi-icon-box">
                                    <div class="mr-3 wi-icon-icon">
                                     <img src="{{asset('assets/img/help-circle-outline.png')}}" alt="" class=" wi-icon">
                                    </div>
                                   <div class="wi-icon-content-box">
                                    <p class="wi-icon-content">help, information about the function you are accessing</p>
                                 </div>
                                </div>
    
                                <div class=" wi-icon-box">
                                    <div class="mr-3 wi-icon-icon">
                                     <img src="{{asset('assets/img/instagram.png')}}" alt="" class=" wi-icon">
                                    </div>
                                   <div class="wi-icon-content-box">
                                    <p class="wi-icon-content">means the platform known as Instagram</p>
                                 </div>
                                </div>
    
                                <div class=" wi-icon-box">
                                    <div class="mr-3 wi-icon-icon">
                                     <img src="{{asset('assets/img/incalls.png')}}" alt="" class=" wi-icon">
                                    </div>
                                   <div class="wi-icon-content-box">
                                    <p class="wi-icon-content">means the Advertiser offers an in-call service</p>
                                 </div>
                                </div>
    
                                <div class=" wi-icon-box">
                                    <div class="mr-3 wi-icon-icon">
                                     <img src="{{asset('assets/img/advertiser rate.png')}}" alt="" class=" wi-icon">
                                    </div>
                                   <div class="wi-icon-content-box">
                                    <p class="wi-icon-content">means a single Advertiser’s rates</p>
                                 </div>
                                </div>
    
                                <div class=" wi-icon-box">
                                    <div class="mr-3 wi-icon-icon">
                                     <img src="{{asset('assets/img/massage.png')}}" alt="" class=" wi-icon">
                                    </div>
                                   <div class="wi-icon-content-box">
                                    <p class="wi-icon-content">means the hourly rate for a massage</p>
                                 </div>
                                </div>
    
                                <div class=" wi-icon-box">
                                    <div class="mr-3 wi-icon-icon">
                                     <img src="{{asset('assets/img/male-user.png')}}" alt="" class=" wi-icon">
                                    </div>
                                   <div class="wi-icon-content-box">
                                    <p class="wi-icon-content">means male</p>
                                 </div>
                                </div>
    
                                <div class=" wi-icon-box">
                                    <div class="mr-3 wi-icon-icon">
                                     <img src="{{asset('assets/img/notification.png')}}" alt="" class=" wi-icon">
                                    </div>
                                   <div class="wi-icon-content-box">
                                    <p class="wi-icon-content">means you have a notification</p>
                                 </div>
                                </div>
                                   
                                <div class=" wi-icon-box">
                                    <div class="mr-3 wi-icon-icon">
                                     <img src="{{asset('assets/img/outcall.png')}}" alt="" class=" wi-icon">
                                    </div>
                                   <div class="wi-icon-content-box">
                                    <p class="wi-icon-content">means the Advertiser offers an out-call service</p>
                                 </div>
                                </div>
                          
                             </div>
                                <div class="col-sm-12 col-lg-6 col-md-6 ">
                                    <div class=" wi-icon-box">
                                        <div class="mr-3 wi-icon-icon">
                                        <img src="{{asset('assets/img/legbox unsave.png')}}" alt="" class=" wi-icon">
                                        </div>
                                    <div class="wi-icon-content-box">
                                        <p class="wi-icon-content">means the Advertiser has not been saved to your Legbox</p>
                                    </div>
                                    </div>

                                    <div class=" wi-icon-box">
                                        <div class="mr-3 wi-icon-icon">
                                        <img src="{{asset('assets/img/legbox save.png')}}" alt="" class=" wi-icon">
                                        </div>
                                        <div class="wi-icon-content-box">
                                            <p class="wi-icon-content">means the Advertiser has been saved to your Legbox</p>
                                        </div>
                                    </div>
                                    
                                    <div class=" wi-icon-box">
                                        <div class="mr-3 wi-icon-icon">
                                        <img src="{{asset('assets/img/access shortlist.png')}}" alt="" class=" wi-icon">
                                        </div>
                                        <div class="wi-icon-content-box">
                                            <p class="wi-icon-content">means access your shortlist</p>
                                        </div>
                                    </div>

                                    <div class=" wi-icon-box">
                                        <div class="mr-3 wi-icon-icon">
                                        <img src="{{asset('assets/img/text advertiser.png')}}" alt="" class=" wi-icon">
                                        </div>
                                        <div class="wi-icon-content-box">
                                            <p class="wi-icon-content">means any User can text an Advertiser</p>
                                        </div>
                                    </div>

                                    <div class=" wi-icon-box">
                                        <div class="mr-3 wi-icon-icon">
                                        <img src="{{asset('assets/img/tickets.png')}}" alt="" class=" wi-icon">
                                        </div>
                                        <div class="wi-icon-content-box">
                                            <p class="wi-icon-content">means tickets notifications</p>
                                        </div>
                                    </div>

                                    
                                    <div class=" wi-icon-box">
                                        <div class="mr-3 wi-icon-icon">
                                        <img src="{{asset('assets/img/transgender.png')}}" alt="" class=" wi-icon">
                                        </div>
                                        <div class="wi-icon-content-box">
                                            <p class="wi-icon-content">means transgendermeans transgender</p>
                                        </div>
                                    </div>

                                    <div class=" wi-icon-box">
                                        <div class="mr-3 wi-icon-icon">
                                        <img src="{{asset('assets/img/Twitter.png')}}" alt="" class=" wi-icon">
                                        </div>
                                        <div class="wi-icon-content-box">
                                            <p class="wi-icon-content">means the platform known as Twitter</p>
                                        </div>
                                    </div>

                                    <div class=" wi-icon-box">
                                        <div class="mr-3 wi-icon-icon">
                                        <img src="{{asset('assets/img/media verified.png')}}" alt="" class=" wi-icon">
                                        </div>
                                        <div class="wi-icon-content-box">
                                            <p class="wi-icon-content">means the Advertiser's Media has been verified</p>
                                        </div>
                                    </div>

                                    
                                    <div class=" wi-icon-box">
                                        <div class="mr-3 wi-icon-icon">
                                        <img src="{{asset('assets/img/verified media.png')}}" alt="" class=" wi-icon">
                                        </div>
                                        <div class="wi-icon-content-box">
                                            <p class="wi-icon-content">means the Advertiser's Media has been verified</p>
                                        </div>
                                    </div>

                                    <div class=" wi-icon-box">
                                        <div class="mr-3 wi-icon-icon">
                                        <img src="{{asset('assets/img/video on profile.png')}}" alt="" class=" wi-icon">
                                        </div>
                                        <div class="wi-icon-content-box">
                                            <p class="wi-icon-content">means the Advertiser has a video in their Profile</p>
                                        </div>
                                    </div>

                                    <div class=" wi-icon-box">
                                        <div class="mr-3 wi-icon-icon">
                                        <img src="{{asset('assets/img/female.png')}}" alt="" class=" wi-icon">
                                        </div>
                                        <div class="wi-icon-content-box">
                                            <p class="wi-icon-content">means female</p>
                                        </div>
                                    </div>

                                  
                                </div>
                            </div>
                        </div>
               </div>
           </div>
           
            <!--                  <div class="set">
                <a>
                Products
                <i class="fa fa-angle-down"></i>
                </a>
                <div class="content">
                   <div class="accodien_manage_padding_content">
                      <p>Escorts4U has partnered with the Condom Man where you can order products online and they will be delivered to your door. For more information about ordering <span class="text_decoration_for_a"><a href="#" class="termsandconditions_text_color">products</a></span> go to Products. (This service is only available to Perth Escorts).</p>
                   </div>
                </div>
                </div> 
                -->
        </div>
    </div>
</section>
@endsection
@push('scripts')
<script>
    var skipSliderage = document.getElementById("skipstepage");
    var skipValuesage = [
    document.getElementById("skip-value-lower-age"),
    document.getElementById("skip-value-upper-age")
    ];
    
    noUiSlider.create(skipSliderage, {
    start: [0, 30],
    connect: true,
    behaviour: "drag",
    step: 1,
    range: {
       min: 18,
       max: 60
    },
    format: {
       from: function (value) {
          return parseInt(value);
       },
       to: function (value) {
          return parseInt(value);
       }
    }
    });
    
    skipSliderage.noUiSlider.on("update", function (values, handle) {
    skipValuesage[handle].innerHTML = values[handle];
    });
    
</script>
@endpush