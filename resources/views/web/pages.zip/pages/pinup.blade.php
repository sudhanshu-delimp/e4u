@extends('layouts.web')
@section('style')
<style>
    .loader {
    border: 16px solid #f3f3f3;
    border-radius: 50%;
    border-top: 16px solid #3498db;
    width: 120px;
    height: 120px;
    -webkit-animation: spin 2s linear infinite; /* Safari */
    animation: spin 2s linear infinite;
    }
    /* Safari */
    @-webkit-keyframes spin {
    0% { -webkit-transform: rotate(0deg); }
    100% { -webkit-transform: rotate(360deg); }
    }
    @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
    }
</style>
@endsection
@section('content')
<section class="padding_top_eight_px padding_bottom_eight_px footer-links-si">
   <div class="container">
      <h1 class="home_heading_first">REGISTER YOUR INTEREST - E4U PIN UP</h1>
      <h2 class="primery_color normal_heading">Timing</h2>
      <p>Our Pin Up feature is very popular with Advertisers. Register your interest to be our Pin Up and when your turn arrives, we will send you a message for you to confirm you still wish to appear as our Pin Up on the home page.
</p>
<h2 class="primery_color normal_heading">Cost</h2>
<p>The Pin UP feature is only available for one week at $475.00, but you can register as often as you like to re-appear as our Pin Up.
</p>
<h2 class="primery_color normal_heading">Where to register</h2>
<p>To register your interest, Advertisers need to <a href="{{ route('advertiser.login') }}" class="termsandconditions_text_color text-decoration-none">logon</a> and at their Dashboard:</p>

<ul>
      <li><p class="mb-0">Click "Profiles & Tours" and select Register for Pin Up link</p></li>
   <li><p class="mb-0">Follow the instructions</p></li>
   <li><p class="mb-0">Proceed to complete your enquiry from the landing page</p></li>
</ul>

</section>
@endsection
@push('scripts')
<script>
    var skipSliderage = document.getElementById("skipstepage");
    var skipValuesage = [
    document.getElementById("skip-value-lower-age"),
    document.getElementById("skip-value-upper-age")
    ];
    
    noUiSlider.create(skipSliderage, {
    start: [0, 30],
    connect: true,
    behaviour: "drag",
    step: 1,
    range: {
       min: 18,
       max: 60
    },
    format: {
       from: function (value) {
          return parseInt(value);
       },
       to: function (value) {
          return parseInt(value);
       }
    }
    });
    
    skipSliderage.noUiSlider.on("update", function (values, handle) {
    skipValuesage[handle].innerHTML = values[handle];
    });
    
</script>

@endpush